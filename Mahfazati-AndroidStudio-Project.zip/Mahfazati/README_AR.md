# محفظتي - مصاريفي (Mahfazati)

تطبيق أندرويد أصلي: Kotlin + Jetpack Compose + Room + MVVM + Material 3، عربي RTL كامل، يعمل دون إنترنت، العملة الريال اليمني فقط.

## كيف تحصل على Mahfazati.apk

### الطريقة 1: Android Studio
1. افتح المجلد في Android Studio (Hedgehog أو أحدث) وانتظر مزامنة Gradle.
2. Build ← Generate Signed Bundle / APK ← APK ← أنشئ مفتاح توقيع جديداً واحفظه (مهم للتحديثات).
3. اختر release، وستجد الملف في app/release. غيّر اسمه إلى Mahfazati.apk.

### الطريقة 2: بدون كمبيوتر (GitHub Actions)
1. أنشئ مستودعاً على GitHub وارفع محتوى هذا المجلد.
2. من تبويب Actions شغّل "Build Mahfazati APK".
3. بعد دقائق نزّل Mahfazati.apk من Artifacts.
(للتحديثات فوق نسخة مثبتة: أضف Secrets: KEYSTORE_B64, KEYSTORE_PASSWORD, KEY_ALIAS لتثبيت مفتاح التوقيع.)

## ملاحظات
- المبالغ أعداد صحيحة بالريال اليمني (بدون كسور).
- الرقم السري يُحفظ كبصمة PBKDF2 مع ملح، وتُقفل الشاشة عند مغادرة التطبيق.
- الاختبارات الآلية: app/src/test (الرصيد، الديون، التكرار الشهري، النسخ الاحتياطي).
