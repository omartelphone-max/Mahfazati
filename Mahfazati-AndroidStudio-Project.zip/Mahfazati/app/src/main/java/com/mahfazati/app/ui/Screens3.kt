@file:OptIn(ExperimentalMaterial3Api::class)

package com.mahfazati.app.ui

import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.mahfazati.app.*
import com.mahfazati.app.data.*
import com.mahfazati.app.export.Export
import com.mahfazati.app.export.PL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate
import java.util.Locale

private fun catName(cats: List<Category>, id: Long?) = cats.firstOrNull { it.id == id }?.name ?: "غير مصنف"

@Composable
private fun CmpRow(label: String, cur: Long, prev: Long) {
    val diff = cur - prev
    val pct = if (prev != 0L) String.format(Locale.US, "%.0f", 100.0 * diff / prev) + "%" else "—"
    Column {
        Text(label, fontWeight = FontWeight.Bold)
        Text("هذا الشهر: ${fmt(cur)}   |   السابق: ${fmt(prev)}", style = MaterialTheme.typography.bodySmall)
        Text("الفرق: ${if (diff > 0) "+" else ""}${fmt(diff)} ($pct)", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun ReportsScreen(vm: AppVM) {
    val txs by vm.txs.collectAsState()
    val cats by vm.categories.collectAsState()
    val accs by vm.accounts.collectAsState()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var y by remember { mutableIntStateOf(LocalDate.now().year) }
    var m by remember { mutableIntStateOf(LocalDate.now().monthValue) }

    val mt = monthOf(txs, y, m)
    val income = sumType(mt, Ty.INCOME)
    val expense = sumType(mt, Ty.EXPENSE)
    val debtNet = sumType(mt, Ty.DEBT_IN) - sumType(mt, Ty.DEBT_OUT)
    val pm = if (m == 1) 12 else m - 1
    val py = if (m == 1) y - 1 else y
    val prev = monthOf(txs, py, pm)
    val catTotals = mt.filter { it.type == Ty.EXPENSE }.groupBy { it.categoryId }
        .map { (id, l) -> catName(cats, id) to l.sumOf { it.amount } }.sortedByDescending { it.second }
    val yearTx = txs.filter { ld(it.date).year == y }
    val incYear = (1..12).map { mm -> sumType(monthOf(yearTx, y, mm), Ty.INCOME) }
    val expYear = (1..12).map { mm -> sumType(monthOf(yearTx, y, mm), Ty.EXPENSE) }

    fun export(pdf: Boolean) {
        scope.launch {
            try {
                val dir = vm.exportDir()
                val name = "Mahfazati-$y-$m"
                val file = withContext(Dispatchers.IO) {
                    val rows = mt.sortedBy { it.date }
                    fun cell(t: Tx) = when (t.type) { Ty.EXPENSE -> catName(cats, t.categoryId); Ty.INCOME -> t.source ?: ""; else -> t.note }
                    fun accN(t: Tx) = accs.firstOrNull { it.id == t.accountId }?.name ?: ""
                    if (pdf) {
                        val f = File(dir, "$name.pdf")
                        val lines = mutableListOf<PL>()
                        lines += PL(listOf("تقرير محفظتي - مصاريفي"), 20f, true)
                        lines += PL(listOf("الشهر: ${MONTHS[m - 1]} $y"), 14f, true)
                        lines += PL(listOf("إجمالي الدخل: ${fmt(income)}"), 12f)
                        lines += PL(listOf("إجمالي المصاريف: ${fmt(expense)}"), 12f)
                        lines += PL(listOf("صافي التدفق (دخل - مصروف): ${fmt(income - expense)}"), 12f, true)
                        lines += PL(listOf(""), 8f)
                        lines += PL(listOf("المصاريف حسب التصنيف"), 13f, true)
                        catTotals.forEach { lines += PL(listOf(it.first, fmt(it.second)), 11f, false, listOf(0.6f, 0.4f)) }
                        lines += PL(listOf(""), 8f)
                        lines += PL(listOf("العمليات"), 13f, true)
                        lines += PL(listOf("التاريخ", "النوع", "التصنيف/الوصف", "الحساب", "ملاحظة", "المبلغ"), 10f, true, listOf(.16f, .12f, .20f, .16f, .22f, .14f))
                        rows.forEach {
                            lines += PL(listOf(dstr(ld(it.date)), typeLabel(it.type), cell(it), accN(it), if (it.type <= 1) it.note else "",
                                (if (signed(it) > 0) "+" else "-") + fmt(it.amount)), 10f, false, listOf(.16f, .12f, .20f, .16f, .22f, .14f))
                        }
                        Export.pdf(f, lines)
                        f
                    } else {
                        val f = File(dir, "$name.xlsx")
                        val data = mutableListOf<List<Any?>>()
                        data += listOf("تقرير محفظتي - مصاريفي")
                        data += listOf("الشهر", "${MONTHS[m - 1]} $y")
                        data += listOf("إجمالي الدخل", income)
                        data += listOf("إجمالي المصاريف", expense)
                        data += listOf("صافي التدفق", income - expense)
                        data += listOf<Any?>()
                        data += listOf("التصنيف", "المبلغ")
                        catTotals.forEach { data += listOf(it.first, it.second) }
                        data += listOf<Any?>()
                        data += listOf("التاريخ", "اليوم", "النوع", "التصنيف/الوصف", "الحساب", "ملاحظة", "المبلغ (بالسالب للصادر)")
                        rows.forEach { data += listOf(dstr(ld(it.date)), dayName(ld(it.date)), typeLabel(it.type), cell(it), accN(it), it.note, signed(it)) }
                        Export.xlsx(f, "تقرير", data)
                        f
                    }
                }
                vm.suppressLock = true
                Export.share(ctx, file, if (pdf) "application/pdf" else "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            } catch (e: Exception) {
                vm.msg("تعذر إنشاء الملف: ${e.message}")
            }
        }
    }

    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("التقارير", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary) }
        item {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { if (m == 12) { m = 1; y++ } else m++ }) { Text("التالي") }
                    Text("${MONTHS[m - 1]} $y", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    TextButton(onClick = { if (m == 1) { m = 12; y-- } else m-- }) { Text("السابق") }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { y++ }) { Text("السنة +") }
                    Text("السنة: $y", Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    TextButton(onClick = { y-- }) { Text("السنة -") }
                }
            } }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("المصاريف", fmt(expense), Modifier.weight(1f))
                StatCard("الدخل", fmt(income), Modifier.weight(1f))
            }
        }
        item {
            StatCard("صافي التدفق (دخل - مصروف)", fmt(income - expense), Modifier.fillMaxWidth(), MaterialTheme.colorScheme.primaryContainer)
        }
        if (debtNet != 0L) item { Text("حركات الديون هذا الشهر (وارد - صادر): ${fmt(debtNet)}", style = MaterialTheme.typography.bodySmall) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { export(false) }, Modifier.weight(1f).height(50.dp)) { Text("تصدير Excel") }
                Button(onClick = { export(true) }, Modifier.weight(1f).height(50.dp)) { Text("تصدير PDF") }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("مقارنة مع ${MONTHS[pm - 1]} $py", style = MaterialTheme.typography.titleMedium)
                CmpRow("المصاريف", expense, sumType(prev, Ty.EXPENSE))
                CmpRow("الدخل", income, sumType(prev, Ty.INCOME))
                CmpRow("الصافي", income - expense, sumType(prev, Ty.INCOME) - sumType(prev, Ty.EXPENSE))
            } }
        }
        item {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("المصاريف حسب التصنيف", style = MaterialTheme.typography.titleMedium)
                if (catTotals.isEmpty()) Text("لا توجد مصاريف في هذا الشهر")
                else {
                    Text("الأكثر استهلاكاً: ${catTotals.first().first} (${fmt(catTotals.first().second)})", fontWeight = FontWeight.Bold)
                    PieChart(catTotals)
                }
            } }
        }
        item {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("الدخل والمصاريف خلال $y", style = MaterialTheme.typography.titleMedium)
                BarChart((1..12).map { it.toString() }, incYear, expYear, MaterialTheme.colorScheme.primary, Gold)
                Text("الأخضر: الدخل   |   الذهبي: المصاريف   |   الأشهر من 1 إلى 12 (من اليمين)", style = MaterialTheme.typography.bodySmall)
            } }
        }
    }
}

@Composable
fun MoreScreen(nav: NavController) {
    val items = listOf(
        "accounts" to "الحسابات والأرصدة",
        "budget" to "الميزانية الشهرية",
        "recurring" to "المصاريف المتكررة",
        "backup" to "النسخ الاحتياطي والاستعادة",
        "settings" to "الإعدادات والحماية"
    )
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("المزيد", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
        items.forEach { (r, l) ->
            ElevatedCard(onClick = { nav.navigate(r) }, Modifier.fillMaxWidth()) {
                Text(l, Modifier.padding(20.dp), style = MaterialTheme.typography.titleMedium)
            }
        }
    }
}

@Composable
fun BudgetScreen(vm: AppVM, nav: NavController) {
    val txs by vm.txs.collectAsState()
    val budgets by vm.budgets.collectAsState()
    val today = LocalDate.now()
    val b = effectiveBudget(budgets, ymOf(today))
    val spent = sumType(monthOf(txs, today.year, today.monthValue), Ty.EXPENSE)
    var amount by remember { mutableStateOf("") }
    SubPage("الميزانية الشهرية", { nav.popBackStack() }) {
        Text("الشهر الحالي: ${MONTHS[today.monthValue - 1]} ${today.year}")
        if (b != null) {
            Text("الميزانية الحالية: ${fmt(b.amount)}", style = MaterialTheme.typography.titleMedium)
            BudgetBar(spent, b.amount)
            Text("المتبقي: ${fmt(b.amount - spent)}")
        } else Text("لم تحدد ميزانية بعد")
        AmountField(amount, { amount = it }, "ميزانية الشهر (ريال يمني)")
        Text("تسري الميزانية على هذا الشهر والأشهر التالية حتى تغييرها. تنبيه عند 80% وعند 100%.", style = MaterialTheme.typography.bodySmall)
        Button(onClick = {
            val a = parseMoney(amount)
            if (a == null) vm.msg("أدخل ميزانية صحيحة") else { vm.setBudget(a); amount = "" }
        }, Modifier.fillMaxWidth().height(52.dp)) { Text("حفظ الميزانية") }
    }
}

@Composable
fun RecurringScreen(vm: AppVM, nav: NavController) {
    val recs by vm.recurring.collectAsState()
    val cats by vm.categories.collectAsState()
    val accs by vm.accounts.collectAsState()
    var adding by remember { mutableStateOf(false) }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var freq by remember { mutableIntStateOf(2) }
    var first by remember { mutableStateOf(LocalDate.now()) }
    var catId by remember { mutableStateOf<Long?>(null) }
    var accId by remember { mutableStateOf<Long?>(null) }
    val selCat = catId ?: cats.firstOrNull()?.id
    val selAcc = accId ?: accs.firstOrNull()?.id

    SubPage("المصاريف المتكررة", { nav.popBackStack() }) {
        Button(onClick = { amount = ""; note = ""; first = LocalDate.now(); adding = true }, Modifier.fillMaxWidth().height(50.dp)) { Text("إضافة مصروف متكرر") }
        Text("يُسجَّل المصروف تلقائياً عند حلول موعده (عند فتح التطبيق)، ولا يتكرر تسجيل نفس الموعد مرتين.", style = MaterialTheme.typography.bodySmall)
        if (recs.isEmpty()) Text("لا توجد مصاريف متكررة")
        recs.forEach { r ->
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("${fmt(r.amount)} — ${FREQS[r.frequency]}", style = MaterialTheme.typography.titleMedium)
                Text("${catName(cats, r.categoryId)} • ${accs.firstOrNull { it.id == r.accountId }?.name ?: ""}")
                if (r.note.isNotBlank()) Text(r.note, style = MaterialTheme.typography.bodySmall)
                Text("الموعد القادم: ${dstr(ld(r.nextDate))}", style = MaterialTheme.typography.bodySmall)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Switch(checked = r.active, onCheckedChange = { vm.toggleRecurring(r) })
                    Text(if (r.active) "مفعّل" else "متوقف", Modifier.weight(1f))
                    TextButton(onClick = { vm.deleteRecurring(r) }) { Text("حذف") }
                }
            } }
        }
    }
    if (adding) FormDialog("مصروف متكرر", onDismiss = { adding = false }, onOk = {
        val a = parseMoney(amount)
        val acc = selAcc
        if (a == null) vm.msg("أدخل مبلغاً صحيحاً") else if (acc == null) vm.msg("اختر الحساب")
        else vm.addRecurring(a, selCat, acc, note, freq, first) { adding = false }
    }) {
        AmountField(amount, { amount = it })
        Dropdown("التكرار", listOf(0, 1, 2), FREQS[freq], { FREQS[it] }) { freq = it }
        DateField("أول موعد", first) { first = it }
        Dropdown("التصنيف", cats, cats.firstOrNull { it.id == selCat }?.name ?: "", { it.name }) { catId = it.id }
        Dropdown("الحساب", accs, accs.firstOrNull { it.id == selAcc }?.name ?: "", { it.name }) { accId = it.id }
        OutlinedTextField(note, { note = it }, label = { Text("ملاحظة") }, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
fun BackupScreen(vm: AppVM, nav: NavController) {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<BackupData?>(null) }
    var confirmReplace by remember { mutableStateOf(false) }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.saveBackup(uri)
    }
    val opener = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.readBackup(uri) { pending = it }
    }
    SubPage("النسخ الاحتياطي والاستعادة", { nav.popBackStack() }) {
        Text("النسخة الاحتياطية ملف JSON كامل (الحسابات، العمليات، الديون، الميزانية، المتكررة) مع فحص سلامة قبل الاستعادة.", style = MaterialTheme.typography.bodySmall)
        Button(onClick = { vm.suppressLock = true; saver.launch("Mahfazati-backup-${LocalDate.now()}.json") }, Modifier.fillMaxWidth().height(50.dp)) { Text("حفظ نسخة احتياطية في ملف") }
        OutlinedButton(onClick = {
            vm.backupToCache { f -> vm.suppressLock = true; Export.share(ctx, f, "application/json") }
        }, Modifier.fillMaxWidth().height(50.dp)) { Text("مشاركة نسخة احتياطية") }
        HorizontalDivider()
        Button(onClick = { vm.suppressLock = true; opener.launch(arrayOf("*/*")) }, Modifier.fillMaxWidth().height(50.dp)) { Text("استعادة من ملف") }
    }
    pending?.let { d ->
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text("ملف صالح ✓") },
            text = {
                Text("يحتوي على: ${d.accounts.size} حساب، ${d.txs.size} عملية، ${d.debts.size} دين.\n\n" +
                    "دمج: يضيف غير الموجود فقط ولا يحذف شيئاً.\nاستبدال: يحذف كل البيانات الحالية ويضع بيانات الملف.\n" +
                    "يُحفظ تلقائياً نسخة أمان قبل الاستعادة.")
            },
            confirmButton = { TextButton(onClick = { vm.restore(d, false) { pending = null } }) { Text("دمج") } },
            dismissButton = {
                Row {
                    TextButton(onClick = { confirmReplace = true }) { Text("استبدال") }
                    TextButton(onClick = { pending = null }) { Text("إلغاء") }
                }
            }
        )
    }
    if (confirmReplace && pending != null) {
        val d = pending!!
        AlertDialog(
            onDismissRequest = { confirmReplace = false },
            title = { Text("تأكيد الاستبدال") },
            text = { Text("سيتم حذف جميع البيانات الحالية واستبدالها ببيانات الملف. هل أنت متأكد؟") },
            confirmButton = { TextButton(onClick = { vm.restore(d, true) { pending = null; confirmReplace = false } }) { Text("نعم، استبدل") } },
            dismissButton = { TextButton(onClick = { confirmReplace = false }) { Text("إلغاء") } }
        )
    }
}

@Composable
fun SettingsScreen(vm: AppVM, nav: NavController) {
    val mode by vm.themeMode.collectAsState()
    var dlg by remember { mutableStateOf(false) }
    var oldP by remember { mutableStateOf("") }
    var newP by remember { mutableStateOf("") }
    var conf by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    SubPage("الإعدادات والحماية", { nav.popBackStack() }) {
        SectionTitle("المظهر")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("حسب النظام", "نهاري", "ليلي").forEachIndexed { i, l ->
                FilterChip(selected = mode == i, onClick = { vm.setTheme(i) }, label = { Text(l) })
            }
        }
        SectionTitle("الحماية")
        Button(onClick = { oldP = ""; newP = ""; conf = ""; err = null; dlg = true }, Modifier.fillMaxWidth().height(50.dp)) { Text("تغيير الرقم السري") }
        Text("الرقم السري لا يُخزَّن كنص، بل كبصمة مشفّرة (PBKDF2) مع ملح عشوائي. يُقفل التطبيق عند الخروج منه.", style = MaterialTheme.typography.bodySmall)
        SectionTitle("عن التطبيق")
        Text("محفظتي - مصاريفي • الإصدار 1.0 • يعمل دون إنترنت • العملة: الريال اليمني (YER)", style = MaterialTheme.typography.bodySmall)
    }
    if (dlg) FormDialog("تغيير الرقم السري", onDismiss = { dlg = false }, onOk = {
        vm.changePin(oldP, newP, conf) { e -> err = e; if (e == null) dlg = false }
    }) {
        listOf(Triple("الرقم الحالي", oldP, { v: String -> oldP = v.take(8) }),
            Triple("الرقم الجديد", newP, { v: String -> newP = v.take(8) }),
            Triple("تأكيد الجديد", conf, { v: String -> conf = v.take(8) })).forEach { (l, v, set) ->
            OutlinedTextField(v, { set(it.filter { c -> c.isDigit() }) }, label = { Text(l) }, singleLine = true,
                visualTransformation = PasswordVisualTransformation())
        }
        err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}
