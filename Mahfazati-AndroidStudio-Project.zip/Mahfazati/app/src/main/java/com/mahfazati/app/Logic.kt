package com.mahfazati.app

import com.mahfazati.app.data.*
import java.text.NumberFormat
import java.time.LocalDate
import java.time.format.TextStyle
import java.util.Locale

object Ty { const val EXPENSE = 0; const val INCOME = 1; const val DEBT_IN = 2; const val DEBT_OUT = 3 }

val MONTHS = listOf("يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر")
val SOURCES = listOf("راتب", "عمل إضافي", "تحويل", "إيداع نقدي", "دخل آخر")
val FREQS = listOf("يومي", "أسبوعي", "شهري")

fun signed(t: Tx): Long = if (t.type == Ty.INCOME || t.type == Ty.DEBT_IN) t.amount else -t.amount
fun fmt(n: Long): String = NumberFormat.getInstance(Locale.US).format(n) + " ر.ي"

fun toWestern(s: String): String = s.map {
    when (it) {
        in '٠'..'٩' -> '0' + (it - '٠')
        in '۰'..'۹' -> '0' + (it - '۰')
        else -> it
    }
}.joinToString("")

/** يحوّل النص إلى مبلغ صحيح بالريال اليمني، ويرجع null إن كان غير صالح */
fun parseMoney(raw: String, allowZero: Boolean = false): Long? {
    val s = toWestern(raw.trim()).filter { it != ',' && it != '،' && it != '٬' && it != ' ' }
    if (s.isEmpty() || s.length > 13 || !s.all { it in '0'..'9' }) return null
    val v = s.toLongOrNull() ?: return null
    return if (v > 0 || (allowZero && v == 0L)) v else null
}

fun ld(epochDay: Long): LocalDate = LocalDate.ofEpochDay(epochDay)
fun dstr(d: LocalDate): String = String.format(Locale.US, "%04d/%02d/%02d", d.year, d.monthValue, d.dayOfMonth)
fun dayName(d: LocalDate): String = d.dayOfWeek.getDisplayName(TextStyle.FULL, Locale("ar"))
fun ymOf(d: LocalDate): Int = d.year * 100 + d.monthValue
fun typeLabel(t: Int): String = when (t) { 0 -> "مصروف"; 1 -> "دخل"; 2 -> "دين وارد"; else -> "دين صادر" }

fun balanceOf(a: Account, txs: List<Tx>): Long = a.openingBalance + txs.filter { it.accountId == a.id }.sumOf { signed(it) }

fun nextDate(cur: Long, freq: Int, anchorDay: Int): Long = when (freq) {
    0 -> cur + 1
    1 -> cur + 7
    else -> {
        val d = LocalDate.ofEpochDay(cur).plusMonths(1)
        d.withDayOfMonth(minOf(anchorDay, d.lengthOfMonth())).toEpochDay()
    }
}

fun effectiveBudget(budgets: List<Budget>, ym: Int): Budget? = budgets.filter { it.ym <= ym }.maxByOrNull { it.ym }

fun monthOf(txs: List<Tx>, y: Int, m: Int): List<Tx> = txs.filter { val d = ld(it.date); d.year == y && d.monthValue == m }
fun sumType(l: List<Tx>, type: Int): Long = l.filter { it.type == type }.sumOf { it.amount }

fun matchesQuery(t: Tx, q: String, cats: List<Category>, accs: List<Account>): Boolean {
    val s = toWestern(q).trim().lowercase()
    if (s.isEmpty()) return true
    val d = ld(t.date)
    val hay = listOf(
        t.amount.toString(), fmt(t.amount), t.note,
        cats.firstOrNull { it.id == t.categoryId }?.name ?: "", t.source ?: "",
        dstr(d), dstr(d).replace('/', '-'), dayName(d), typeLabel(t.type),
        accs.firstOrNull { it.id == t.accountId }?.name ?: ""
    ).joinToString(" ").lowercase()
    return s.split(" ").filter { it.isNotBlank() }.all { hay.contains(it) }
}
