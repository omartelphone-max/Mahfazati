package com.mahfazati.app

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mahfazati.app.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

enum class Lock { LOADING, CREATE, LOCKED, OPEN }

class AppVM(app: Application) : AndroidViewModel(app) {
    private val db = AppDb.get(app)
    val repo = Repo(db)
    private val dao = db.dao()

    private fun <T> Flow<T>.state(init: T) = stateIn(viewModelScope, SharingStarted.Eagerly, init)

    val accounts = dao.accounts().state(emptyList())
    val categories = dao.categories().state(emptyList())
    val txs = dao.txs().state(emptyList())
    val debts = dao.debts().state(emptyList())
    val payments = dao.payments().state(emptyList())
    val budgets = dao.budgets().state(emptyList())
    val recurring = dao.recurring().state(emptyList())
    val themeMode = dao.settings()
        .map { l -> l.firstOrNull { it.skey == "theme" }?.sval?.toIntOrNull() ?: 0 }
        .state(0)

    private val msgs = Channel<String>(Channel.BUFFERED)
    val messages = msgs.receiveAsFlow()
    fun msg(s: String) { msgs.trySend(s) }

    private fun launchSafe(onOk: (() -> Unit)? = null, block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
                onOk?.invoke()
            } catch (e: AppError) {
                msg(e.message ?: "خطأ")
            } catch (e: Exception) {
                msg("حدث خطأ غير متوقع: ${e.message}")
            }
        }
    }

    // ---------------- القفل ----------------
    var lock by mutableStateOf(Lock.LOADING)
        private set
    var suppressLock = false
    private var fails = 0
    private var lockedUntil = 0L

    init {
        viewModelScope.launch { lock = if (repo.hasPin()) Lock.LOCKED else Lock.CREATE }
    }

    private fun pinError(p: String, c: String?): String? = when {
        p.length !in 4..8 || !p.all { it in '0'..'9' } -> "الرقم السري من 4 إلى 8 أرقام"
        c != null && p != c -> "تأكيد الرقم السري غير مطابق"
        else -> null
    }

    fun createPin(pin: String, confirm: String): String? {
        val p = toWestern(pin); val c = toWestern(confirm)
        pinError(p, c)?.let { return it }
        viewModelScope.launch {
            repo.setPin(p)
            lock = Lock.OPEN
            afterUnlock()
        }
        return null
    }

    fun unlock(pin: String, result: (String?) -> Unit) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            if (now < lockedUntil) { result("محاولات كثيرة. حاول بعد ${(lockedUntil - now) / 1000 + 1} ثانية"); return@launch }
            if (repo.verifyPin(toWestern(pin))) {
                fails = 0; lock = Lock.OPEN; result(null); afterUnlock()
            } else {
                fails++
                if (fails >= 5) { fails = 0; lockedUntil = now + 30_000; result("محاولات كثيرة. انتظر 30 ثانية") }
                else result("الرقم السري غير صحيح")
            }
        }
    }

    fun changePin(old: String, new: String, confirm: String, result: (String?) -> Unit) {
        viewModelScope.launch {
            val n = toWestern(new)
            val e = pinError(n, toWestern(confirm))
            when {
                !repo.verifyPin(toWestern(old)) -> result("الرقم السري الحالي غير صحيح")
                e != null -> result(e)
                else -> { repo.setPin(n); result(null); msg("تم تغيير الرقم السري") }
            }
        }
    }

    fun onBackground() { if (!suppressLock && lock == Lock.OPEN) lock = Lock.LOCKED }

    private fun afterUnlock() {
        launchSafe {
            val n = repo.processRecurring(LocalDate.now().toEpochDay())
            if (n > 0) {
                msg("تم تسجيل $n مصروف متكرر تلقائياً")
                notifyBudget(LocalDate.now())
            }
        }
    }

    private suspend fun notifyBudget(d: LocalDate) {
        val a = repo.checkBudget(ymOf(d)) ?: return
        Notifier.budget(getApplication(), a)
        msg(Notifier.text(a))
    }

    // ---------------- العمليات ----------------
    fun addExpense(amount: Long, date: LocalDate, accountId: Long, categoryId: Long?, note: String, done: () -> Unit) =
        launchSafe(done) {
            repo.addTx(Tx(type = Ty.EXPENSE, amount = amount, date = date.toEpochDay(), accountId = accountId, categoryId = categoryId, note = note.trim()))
            msg("تم حفظ المصروف")
            notifyBudget(date)
        }

    fun addIncome(amount: Long, date: LocalDate, accountId: Long, source: String, note: String, done: () -> Unit) =
        launchSafe(done) {
            repo.addTx(Tx(type = Ty.INCOME, amount = amount, date = date.toEpochDay(), accountId = accountId, source = source, note = note.trim()))
            msg("تم حفظ الدخل وإضافته إلى الرصيد")
        }

    fun deleteTx(t: Tx) = launchSafe { repo.deleteTx(t); msg("تم حذف العملية وتعديل الرصيد") }

    fun createAccount(name: String, opening: Long) = launchSafe { repo.createAccount(name, opening); msg("تم إنشاء الحساب") }
    fun renameAccount(id: Long, name: String) = launchSafe { repo.renameAccount(id, name); msg("تم تعديل الاسم") }

    fun addDebt(person: String, kind: Int, amount: Long, date: LocalDate, note: String, accountId: Long, affects: Boolean, done: () -> Unit) =
        launchSafe(done) { repo.addDebt(person, kind, amount, date.toEpochDay(), note, accountId, affects); msg("تم تسجيل الدين") }

    fun payDebt(debtId: Long, amount: Long, date: LocalDate, accountId: Long, note: String, done: () -> Unit) =
        launchSafe(done) { repo.payDebt(debtId, amount, date.toEpochDay(), accountId, note); msg("تم تسجيل الدفعة") }

    fun setBudget(amount: Long) = launchSafe {
        repo.setBudget(ymOf(LocalDate.now()), amount)
        msg("تم حفظ الميزانية")
        notifyBudget(LocalDate.now())
    }

    fun addRecurring(amount: Long, categoryId: Long?, accountId: Long, note: String, freq: Int, first: LocalDate, done: () -> Unit) =
        launchSafe(done) {
            repo.addRecurring(Recurring(amount = amount, categoryId = categoryId, accountId = accountId, note = note.trim(),
                frequency = freq, nextDate = first.toEpochDay(), anchorDay = first.dayOfMonth))
            val n = repo.processRecurring(LocalDate.now().toEpochDay())
            msg(if (n > 0) "تم الحفظ وتسجيل $n مصروف مستحق" else "تم حفظ المصروف المتكرر")
            if (n > 0) notifyBudget(LocalDate.now())
        }

    fun toggleRecurring(r: Recurring) = launchSafe { dao.updateRecurring(r.copy(active = !r.active)) }
    fun deleteRecurring(r: Recurring) = launchSafe { dao.deleteRecurring(r); msg("تم حذف المصروف المتكرر (العمليات السابقة باقية)") }
    fun setTheme(mode: Int) = launchSafe { repo.setSetting("theme", mode.toString()) }

    // ---------------- الملفات والنسخ الاحتياطي ----------------
    fun exportDir(): File = File(getApplication<Application>().cacheDir, "exports").apply { mkdirs() }

    fun saveBackup(uri: Uri) = launchSafe {
        val snap = repo.snapshot()
        val json = withContext(Dispatchers.Default) { Backup.export(snap) }
        withContext(Dispatchers.IO) {
            val out = getApplication<Application>().contentResolver.openOutputStream(uri, "wt") ?: throw AppError("تعذر فتح الملف للكتابة")
            out.use { it.write(json.toByteArray(Charsets.UTF_8)) }
        }
        msg("تم حفظ النسخة الاحتياطية")
    }

    fun backupToCache(onFile: (File) -> Unit) = launchSafe {
        val snap = repo.snapshot()
        val json = withContext(Dispatchers.Default) { Backup.export(snap) }
        val name = "Mahfazati-backup-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmm", Locale.US)) + ".json"
        val f = File(exportDir(), name)
        withContext(Dispatchers.IO) { f.writeText(json, Charsets.UTF_8) }
        onFile(f)
    }

    fun readBackup(uri: Uri, onReady: (BackupData) -> Unit) = launchSafe {
        val text = withContext(Dispatchers.IO) {
            val s = getApplication<Application>().contentResolver.openInputStream(uri) ?: throw AppError("تعذر قراءة الملف")
            s.use { String(it.readBytes(), Charsets.UTF_8) }
        }
        val data = withContext(Dispatchers.Default) { Backup.parse(text) }
        onReady(data)
    }

    fun restore(d: BackupData, replace: Boolean, done: () -> Unit) = launchSafe(done) {
        // نسخة أمان تلقائية قبل أي استعادة
        val snap = repo.snapshot()
        val safety = withContext(Dispatchers.Default) { Backup.export(snap) }
        withContext(Dispatchers.IO) { File(exportDir(), "pre-restore-backup.json").writeText(safety, Charsets.UTF_8) }
        repo.restore(d, replace)
        msg(if (replace) "تمت الاستعادة (استبدال) بنجاح" else "تمت الاستعادة (دمج) بنجاح")
    }
}
