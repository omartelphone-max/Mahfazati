@file:OptIn(ExperimentalMaterial3Api::class)

package com.mahfazati.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.mahfazati.app.*
import com.mahfazati.app.data.*
import java.time.LocalDate

@Composable
fun DebtsScreen(vm: AppVM, nav: NavController) {
    val debts by vm.debts.collectAsState()
    val payments by vm.payments.collectAsState()
    val accs by vm.accounts.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var payFor by remember { mutableStateOf<Debt?>(null) }
    val toMe = debts.filter { it.kind == 0 }
    val iOwe = debts.filter { it.kind == 1 }
    val totalToMe = toMe.sumOf { it.remaining }
    val totalIOwe = iOwe.sumOf { it.remaining }
    val list = if (tab == 0) toMe else iOwe

    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("الديون", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary) }
        item {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("إجمالي الديون المستحقة لي: ${fmt(totalToMe)}")
                Text("إجمالي الديون المستحقة عليّ: ${fmt(totalIOwe)}")
                Text("صافي الديون: ${fmt(totalToMe - totalIOwe)}", fontWeight = FontWeight.Bold)
            } }
        }
        item {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("ديون لي عند الآخرين") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("ديون عليّ للآخرين") })
            }
        }
        item { Button(onClick = { nav.navigate("addDebt/$tab") }, Modifier.fillMaxWidth().height(50.dp)) { Text("إضافة دين") } }
        if (list.isEmpty()) item { Text("لا توجد ديون في هذا القسم") }
        items(list, key = { it.id }) { d ->
            val pays = payments.filter { it.debtId == d.id }
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(d.personName, style = MaterialTheme.typography.titleMedium)
                Text("المبلغ الأصلي: ${fmt(d.originalAmount)}")
                Text("المتبقي: ${fmt(d.remaining)}", fontWeight = FontWeight.Bold,
                    color = if (d.remaining == 0L) Positive else MaterialTheme.colorScheme.onSurface)
                Text("التاريخ: ${dstr(ld(d.date))}", style = MaterialTheme.typography.bodySmall)
                if (d.note.isNotBlank()) Text("ملاحظات: ${d.note}", style = MaterialTheme.typography.bodySmall)
                if (pays.isNotEmpty()) {
                    Text(if (d.kind == 0) "المبالغ المستلمة:" else "المبالغ المسددة:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                    pays.forEach { Text("• ${dstr(ld(it.date))}  ${fmt(it.amount)}${if (it.note.isNotBlank()) "  (${it.note})" else ""}", style = MaterialTheme.typography.bodySmall) }
                }
                if (d.remaining > 0) FilledTonalButton(onClick = { payFor = d }) { Text(if (d.kind == 0) "استلمت جزءاً" else "سددت جزءاً") }
                else Text("تم السداد بالكامل", color = Positive)
            } }
        }
    }

    payFor?.let { d ->
        var amount by remember(d.id) { mutableStateOf("") }
        var date by remember(d.id) { mutableStateOf(LocalDate.now()) }
        var note by remember(d.id) { mutableStateOf("") }
        var accId by remember(d.id) { mutableStateOf<Long?>(d.accountId) }
        FormDialog(if (d.kind == 0) "تسجيل مبلغ مستلم" else "تسجيل سداد", "تسجيل", { payFor = null }, {
            val a = parseMoney(amount)
            val acc = accId
            if (a == null) vm.msg("أدخل مبلغاً صحيحاً")
            else if (acc == null) vm.msg("اختر الحساب")
            else vm.payDebt(d.id, a, date, acc, note) { payFor = null }
        }) {
            Text("المتبقي: ${fmt(d.remaining)}")
            AmountField(amount, { amount = it })
            DateField("التاريخ", date) { date = it }
            Dropdown("الحساب", accs, accs.firstOrNull { it.id == accId }?.name ?: "", { it.name }) { accId = it.id }
            OutlinedTextField(note, { note = it }, label = { Text("ملاحظة") }, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
fun AddDebtScreen(vm: AppVM, nav: NavController, kind: Int) {
    val accs by vm.accounts.collectAsState()
    var person by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now()) }
    var note by remember { mutableStateOf("") }
    var accId by remember { mutableStateOf<Long?>(null) }
    var affects by remember { mutableStateOf(true) }
    val selAcc = accId ?: accs.firstOrNull()?.id
    SubPage(if (kind == 0) "دين لي عند شخص" else "دين عليّ لشخص", { nav.popBackStack() }) {
        OutlinedTextField(person, { person = it }, label = { Text("اسم الشخص") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        AmountField(amount, { amount = it }, "المبلغ الأصلي (ريال يمني)")
        DateField("التاريخ", date) { date = it }
        OutlinedTextField(note, { note = it }, label = { Text("ملاحظات") }, modifier = Modifier.fillMaxWidth())
        Dropdown("الحساب", accs, accs.firstOrNull { it.id == selAcc }?.name ?: "", { it.name }) { accId = it.id }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("تسجيل الحركة النقدية على الحساب")
                Text(
                    if (kind == 0) "عند التفعيل يخرج المبلغ من رصيد الحساب (إقراض). لا يُحسب كمصروف."
                    else "عند التفعيل يدخل المبلغ إلى رصيد الحساب (اقتراض). لا يُحسب كدخل.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            Switch(checked = affects, onCheckedChange = { affects = it })
        }
        Button(onClick = {
            val a = parseMoney(amount)
            if (a == null) vm.msg("أدخل مبلغاً صحيحاً أكبر من صفر")
            else if (selAcc == null) vm.msg("اختر الحساب")
            else vm.addDebt(person, kind, a, date, note, selAcc, affects) { nav.popBackStack() }
        }, Modifier.fillMaxWidth().height(54.dp)) { Text("حفظ") }
    }
}
