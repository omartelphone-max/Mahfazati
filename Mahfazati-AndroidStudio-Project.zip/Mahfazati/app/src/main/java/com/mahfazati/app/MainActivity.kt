package com.mahfazati.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mahfazati.app.ui.*

class MainActivity : ComponentActivity() {
    private val vm: AppVM by viewModels()
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val mode by vm.themeMode.collectAsState()
            AppTheme(mode) { Root(vm) }
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            vm.suppressLock = true
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    override fun onResume() { super.onResume(); vm.suppressLock = false }
    override fun onStop() { super.onStop(); vm.onBackground() }
}

@Composable
fun Root(vm: AppVM) {
    when (vm.lock) {
        Lock.LOADING -> Surface(Modifier.fillMaxSize()) { Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() } }
        Lock.CREATE, Lock.LOCKED -> LockScreen(vm)
        Lock.OPEN -> MainNav(vm)
    }
}

@Composable
fun MainNav(vm: AppVM) {
    val nav = rememberNavController()
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.messages.collect { snack.showSnackbar(it) } }
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val tabs = listOf(
        Triple("home", "الرئيسية", Icons.Default.Home),
        Triple("history", "السجل", Icons.Default.Search),
        Triple("debts", "الديون", Icons.Default.Person),
        Triple("reports", "التقارير", Icons.Default.DateRange),
        Triple("more", "المزيد", Icons.Default.Menu)
    )
    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            if (tabs.any { it.first == route }) NavigationBar {
                tabs.forEach { (r, l, ic) ->
                    NavigationBarItem(
                        selected = route == r,
                        onClick = { nav.navigate(r) { popUpTo("home") { saveState = true }; launchSingleTop = true; restoreState = true } },
                        icon = { Icon(ic, l) }, label = { Text(l) }
                    )
                }
            }
        }
    ) { pad ->
        NavHost(nav, "home", Modifier.padding(pad)) {
            composable("home") { DashboardScreen(vm, nav) }
            composable("history") { HistoryScreen(vm) }
            composable("debts") { DebtsScreen(vm, nav) }
            composable("reports") { ReportsScreen(vm) }
            composable("more") { MoreScreen(nav) }
            composable("addExpense") { AddTxScreen(vm, nav, false) }
            composable("addIncome") { AddTxScreen(vm, nav, true) }
            composable("accounts") { AccountsScreen(vm, nav) }
            composable("account/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) {
                AccountDetailScreen(vm, nav, it.arguments!!.getLong("id"))
            }
            composable("addDebt/{kind}", arguments = listOf(navArgument("kind") { type = NavType.IntType })) {
                AddDebtScreen(vm, nav, it.arguments!!.getInt("kind"))
            }
            composable("budget") { BudgetScreen(vm, nav) }
            composable("recurring") { RecurringScreen(vm, nav) }
            composable("backup") { BackupScreen(vm, nav) }
            composable("settings") { SettingsScreen(vm, nav) }
        }
    }
}
