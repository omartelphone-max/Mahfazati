package com.mahfazati.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalLayoutDirection

val Olive = Color(0xFF556B2F)
val Gold = Color(0xFFC9A94B)
val Positive = Color(0xFF2E7D32)

private val LightScheme = lightColorScheme(
    primary = Olive, onPrimary = Color.White,
    primaryContainer = Color(0xFFDDE8C4), onPrimaryContainer = Color(0xFF1B2A05),
    secondary = Gold, onSecondary = Color.Black, secondaryContainer = Color(0xFFF5EBC8), onSecondaryContainer = Color(0xFF3A2F00),
    background = Color(0xFFF3F3F1), surface = Color.White, surfaceVariant = Color(0xFFE9EAE4),
    error = Color(0xFFB3261E)
)
private val DarkScheme = darkColorScheme(
    primary = Color(0xFFA8C46A), onPrimary = Color(0xFF1B2A05),
    primaryContainer = Color(0xFF3E4F20), onPrimaryContainer = Color(0xFFDDE8C4),
    secondary = Color(0xFFE0C36A), onSecondary = Color.Black, secondaryContainer = Color(0xFF4A3F12), onSecondaryContainer = Color(0xFFF5EBC8),
    background = Color(0xFF14160F), surface = Color(0xFF1E211A), surfaceVariant = Color(0xFF2B2F25),
    error = Color(0xFFFFB4AB)
)

private val BigType = Typography().copy(
    titleLarge = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 19.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 18.sp),
    bodyMedium = TextStyle(fontSize = 16.sp),
    bodySmall = TextStyle(fontSize = 14.sp),
    labelLarge = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium)
)

@Composable
fun AppTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    MaterialTheme(colorScheme = if (dark) DarkScheme else LightScheme, typography = BigType) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { content() }
    }
}
