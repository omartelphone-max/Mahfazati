@file:OptIn(ExperimentalMaterial3Api::class)

package com.mahfazati.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.mahfazati.app.*
import com.mahfazati.app.data.*
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters

@Composable
fun LockScreen(vm: AppVM) {
    val creating = vm.lock == Lock.CREATE
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().systemBarsPadding().padding(28.dp),
            verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("محفظتي - مصاريفي", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(10.dp))
            Text(if (creating) "أنشئ رقماً سرياً من 4 إلى 8 أرقام لحماية بياناتك" else "أدخل الرقم السري")
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(
                value = pin, onValueChange = { pin = it.filter { c -> c.isDigit() }.take(8) },
                label = { Text("الرقم السري") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                modifier = Modifier.fillMaxWidth()
            )
            if (creating) {
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = confirm, onValueChange = { confirm = it.filter { c -> c.isDigit() }.take(8) },
                    label = { Text("تأكيد الرقم السري") }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            err?.let { Spacer(Modifier.height(8.dp)); Text(it, color = MaterialTheme.colorScheme.error) }
            Spacer(Modifier.height(18.dp))
            Button(
                onClick = {
                    if (creating) err = vm.createPin(pin, confirm)
                    else vm.unlock(pin) { e -> err = e; if (e != null) pin = "" }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text(if (creating) "حفظ وبدء الاستخدام" else "فتح") }
        }
    }
}

@Composable
fun TxRow(t: Tx, cats: List<Category>, accs: List<Account>, onDelete: ((Tx) -> Unit)? = null) {
    val title = when (t.type) {
        Ty.EXPENSE -> cats.firstOrNull { it.id == t.categoryId }?.name ?: "مصروف"
        Ty.INCOME -> t.source ?: "دخل"
        else -> t.note.ifBlank { typeLabel(t.type) }
    }
    val pos = signed(t) > 0
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text("${dstr(ld(t.date))} • ${accs.firstOrNull { it.id == t.accountId }?.name ?: ""} • ${typeLabel(t.type)}", style = MaterialTheme.typography.bodySmall)
                if (t.note.isNotBlank() && t.type <= 1) Text(t.note, style = MaterialTheme.typography.bodySmall)
            }
            Text(
                (if (pos) "+" else "-") + fmt(t.amount),
                color = if (pos) Positive else MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold
            )
            if (onDelete != null && t.type <= 1) {
                IconButton(onClick = { onDelete(t) }) { Icon(Icons.Default.Delete, "حذف") }
            }
        }
    }
}

@Composable
fun DashboardScreen(vm: AppVM, nav: NavController) {
    val txs by vm.txs.collectAsState()
    val accs by vm.accounts.collectAsState()
    val cats by vm.categories.collectAsState()
    val budgets by vm.budgets.collectAsState()
    val today = LocalDate.now()
    val td = today.toEpochDay()
    val wStart = today.with(TemporalAdjusters.previousOrSame(DayOfWeek.SATURDAY)).toEpochDay()
    val mStart = today.withDayOfMonth(1).toEpochDay()
    val mEnd = today.with(TemporalAdjusters.lastDayOfMonth()).toEpochDay()
    fun exp(f: Long, t: Long) = txs.filter { it.type == Ty.EXPENSE && it.date in f..t }.sumOf { it.amount }
    val balance = accs.sumOf { it.openingBalance } + txs.sumOf { signed(it) }
    val income = txs.filter { it.type == Ty.INCOME }.sumOf { it.amount }
    val totalExp = txs.filter { it.type == Ty.EXPENSE }.sumOf { it.amount }
    val monthly = (1..12).map { m -> monthOf(txs, today.year, m).filter { it.type == Ty.EXPENSE }.sumOf { it.amount } }
    val budget = effectiveBudget(budgets, ymOf(today))
    val spentMonth = exp(mStart, mEnd)

    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("محفظتي - مصاريفي", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary) }
        item {
            StatCard("الرصيد الحالي (كل الحسابات)", fmt(balance), Modifier.fillMaxWidth(), MaterialTheme.colorScheme.primaryContainer)
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(onClick = { nav.navigate("addExpense") }, Modifier.weight(1f).height(52.dp)) { Text("إضافة مصروف") }
                FilledTonalButton(onClick = { nav.navigate("addIncome") }, Modifier.weight(1f).height(52.dp)) { Text("إضافة دخل") }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("مصاريف اليوم", fmt(exp(td, td)), Modifier.weight(1f))
                StatCard("مصاريف الأسبوع", fmt(exp(wStart, wStart + 6)), Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("مصاريف الشهر", fmt(spentMonth), Modifier.weight(1f))
                StatCard("كل المصاريف", fmt(totalExp), Modifier.weight(1f))
            }
        }
        item { StatCard("إجمالي الدخل", fmt(income), Modifier.fillMaxWidth(), MaterialTheme.colorScheme.secondaryContainer) }
        if (budget != null) item {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
                Text("ميزانية الشهر", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                BudgetBar(spentMonth, budget.amount)
            } }
        }
        item {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
                Text("المصاريف الشهرية ${today.year}", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                BarChart((1..12).map { it.toString() }, monthly, null, MaterialTheme.colorScheme.primary)
            } }
        }
        item { SectionTitle("آخر 5 عمليات") }
        if (txs.isEmpty()) item { Text("لا توجد عمليات بعد. ابدأ بإضافة دخل أو مصروف.") }
        items(txs.take(5), key = { it.id }) { TxRow(it, cats, accs) }
    }
}

@Composable
fun HistoryScreen(vm: AppVM) {
    val txs by vm.txs.collectAsState()
    val accs by vm.accounts.collectAsState()
    val cats by vm.categories.collectAsState()
    var q by remember { mutableStateOf("") }
    var typeF by remember { mutableIntStateOf(-1) }
    var accF by remember { mutableStateOf<Long?>(null) }
    var del by remember { mutableStateOf<Tx?>(null) }
    val filtered = remember(txs, q, typeF, accF, cats, accs) {
        txs.filter { (typeF == -1 || it.type == typeF) && (accF == null || it.accountId == accF) && matchesQuery(it, q, cats, accs) }
    }
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp)) {
        Text("سجل العمليات", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 16.dp))
        OutlinedTextField(
            value = q, onValueChange = { q = it }, singleLine = true, label = { Text("بحث: مبلغ، ملاحظة، تصنيف، تاريخ، نوع، حساب") },
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
        )
        Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.weight(1f)) {
                Dropdown("النوع", listOf(-1, 0, 1, 2, 3), if (typeF == -1) "الكل" else typeLabel(typeF), { if (it == -1) "الكل" else typeLabel(it) }) { typeF = it }
            }
            Box(Modifier.weight(1f)) {
                Dropdown("الحساب", listOf<Long?>(null) + accs.map { it.id }, accs.firstOrNull { it.id == accF }?.name ?: "الكل",
                    { id -> accs.firstOrNull { it.id == id }?.name ?: "الكل" }) { accF = it }
            }
        }
        Text("${filtered.size} عملية", style = MaterialTheme.typography.bodySmall)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            if (filtered.isEmpty()) item { Text("لا توجد نتائج") }
            items(filtered, key = { it.id }) { TxRow(it, cats, accs) { t -> del = t } }
        }
    }
    del?.let { t ->
        AlertDialog(
            onDismissRequest = { del = null },
            title = { Text("حذف العملية؟") },
            text = { Text("سيتم حذف ${typeLabel(t.type)} بقيمة ${fmt(t.amount)} وتعديل الرصيد تلقائياً.") },
            confirmButton = { TextButton(onClick = { vm.deleteTx(t); del = null }) { Text("حذف") } },
            dismissButton = { TextButton(onClick = { del = null }) { Text("إلغاء") } }
        )
    }
}

@Composable
fun AddTxScreen(vm: AppVM, nav: NavController, income: Boolean) {
    val accs by vm.accounts.collectAsState()
    val cats by vm.categories.collectAsState()
    var amount by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now()) }
    var catId by remember { mutableStateOf<Long?>(null) }
    var source by remember { mutableStateOf(SOURCES[0]) }
    var note by remember { mutableStateOf("") }
    var accId by remember { mutableStateOf<Long?>(null) }
    val selAcc = accId ?: accs.firstOrNull()?.id
    val selCat = catId ?: cats.firstOrNull()?.id
    var saving by remember { mutableStateOf(false) }

    SubPage(if (income) "إضافة دخل" else "إضافة مصروف", { nav.popBackStack() }) {
        AmountField(amount, { amount = it })
        DateField("التاريخ", date) { date = it }
        OutlinedTextField(value = dayName(date), onValueChange = {}, readOnly = true, label = { Text("اليوم") }, modifier = Modifier.fillMaxWidth())
        if (income) Dropdown("مصدر الدخل", SOURCES, source, { it }) { source = it }
        else Dropdown("التصنيف", cats, cats.firstOrNull { it.id == selCat }?.name ?: "", { it.name }) { catId = it.id }
        OutlinedTextField(value = note, onValueChange = { note = it }, label = { Text("الملاحظة") }, modifier = Modifier.fillMaxWidth())
        Dropdown("الحساب", accs, accs.firstOrNull { it.id == selAcc }?.name ?: "", { it.name }) { accId = it.id }
        Button(
            enabled = !saving,
            onClick = {
                val a = parseMoney(amount)
                if (a == null) vm.msg("أدخل مبلغاً صحيحاً أكبر من صفر (أرقام فقط)")
                else if (selAcc == null) vm.msg("اختر الحساب")
                else {
                    saving = true
                    val done = { nav.popBackStack(); Unit }
                    if (income) vm.addIncome(a, date, selAcc, source, note, done)
                    else vm.addExpense(a, date, selAcc, selCat, note, done)
                }
            },
            modifier = Modifier.fillMaxWidth().height(54.dp)
        ) { Text("حفظ") }
    }
}

@Composable
fun AccountsScreen(vm: AppVM, nav: NavController) {
    val accs by vm.accounts.collectAsState()
    val txs by vm.txs.collectAsState()
    var adding by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Account?>(null) }
    var name by remember { mutableStateOf("") }
    var opening by remember { mutableStateOf("") }

    SubPage("الحسابات (الريال اليمني)", { nav.popBackStack() }) {
        Button(onClick = { name = ""; opening = ""; adding = true }, Modifier.fillMaxWidth().height(50.dp)) { Text("إنشاء حساب جديد") }
        accs.forEach { a ->
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
                Text(a.name, style = MaterialTheme.typography.titleMedium)
                Text(fmt(balanceOf(a, txs)), style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.primary)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { nav.navigate("account/${a.id}") }) { Text("سجل الحساب") }
                    OutlinedButton(onClick = { name = a.name; editing = a }) { Text("تعديل الاسم") }
                }
            } }
        }
    }
    if (adding) FormDialog("حساب جديد", onDismiss = { adding = false }, onOk = {
        vm.createAccount(name, parseMoney(opening, true) ?: 0L); adding = false
    }) {
        OutlinedTextField(name, { name = it }, label = { Text("اسم الحساب") }, singleLine = true)
        AmountField(opening, { opening = it }, "الرصيد الافتتاحي (اختياري)")
    }
    editing?.let { a ->
        FormDialog("تعديل اسم الحساب", onDismiss = { editing = null }, onOk = { vm.renameAccount(a.id, name); editing = null }) {
            OutlinedTextField(name, { name = it }, label = { Text("اسم الحساب") }, singleLine = true)
        }
    }
}

@Composable
fun AccountDetailScreen(vm: AppVM, nav: NavController, id: Long) {
    val accs by vm.accounts.collectAsState()
    val txs by vm.txs.collectAsState()
    val cats by vm.categories.collectAsState()
    val acc = accs.firstOrNull { it.id == id }
    val list = txs.filter { it.accountId == id }
    SubPageLazy(acc?.name ?: "الحساب", { nav.popBackStack() }) {
        if (acc != null) item {
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("التحقق من الرصيد (يُحسب من السجل):", style = MaterialTheme.typography.titleMedium)
                Text("الرصيد الافتتاحي: ${fmt(acc.openingBalance)}")
                Text("+ الدخل: ${fmt(list.filter { it.type == Ty.INCOME }.sumOf { it.amount })}")
                Text("+ ديون واردة/مستلمة: ${fmt(list.filter { it.type == Ty.DEBT_IN }.sumOf { it.amount })}")
                Text("- المصاريف: ${fmt(list.filter { it.type == Ty.EXPENSE }.sumOf { it.amount })}")
                Text("- ديون صادرة/مسددة: ${fmt(list.filter { it.type == Ty.DEBT_OUT }.sumOf { it.amount })}")
                Text("= الرصيد الحالي: ${fmt(balanceOf(acc, txs))}", fontWeight = FontWeight.Bold)
            } }
        }
        if (list.isEmpty()) item { Text("لا توجد عمليات لهذا الحساب") }
        items(list, key = { it.id }) { TxRow(it, cats, accs) }
    }
}
