package com.mahfazati.app.export

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** سطر في ملف PDF. إذا كان w غير null فهو جدول بنسب أعمدة (من اليمين لليسار) */
class PL(val cells: List<String>, val size: Float = 11f, val bold: Boolean = false, val w: List<Float>? = null)

object Export {
    private fun esc(s: String): String = buildString {
        for (c in s) {
            when {
                c == '&' -> append("&amp;")
                c == '<' -> append("&lt;")
                c == '>' -> append("&gt;")
                c == '"' -> append("&quot;")
                c.code < 32 && c != '\n' && c != '\t' -> {}
                else -> append(c)
            }
        }
    }

    /** ملف XLSX حقيقي (Office Open XML) باتجاه من اليمين لليسار. القيم: Long/Int رقمية والباقي نصية */
    fun xlsx(out: File, sheetName: String, rows: List<List<Any?>>) {
        val sb = StringBuilder()
        sb.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>""")
        sb.append("""<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">""")
        sb.append("""<sheetViews><sheetView workbookViewId="0" rightToLeft="1"/></sheetViews>""")
        sb.append("""<cols><col min="1" max="7" width="22" customWidth="1"/></cols><sheetData>""")
        rows.forEachIndexed { ri, row ->
            sb.append("<row r=\"${ri + 1}\">")
            row.forEachIndexed { ci, v ->
                val ref = "${'A' + ci}${ri + 1}"
                when (v) {
                    null -> {}
                    is Long, is Int -> sb.append("<c r=\"$ref\"><v>$v</v></c>")
                    else -> sb.append("<c r=\"$ref\" t=\"inlineStr\"><is><t>${esc(v.toString())}</t></is></c>")
                }
            }
            sb.append("</row>")
        }
        sb.append("</sheetData></worksheet>")

        ZipOutputStream(FileOutputStream(out)).use { z ->
            fun put(name: String, content: String) {
                z.putNextEntry(ZipEntry(name)); z.write(content.toByteArray(Charsets.UTF_8)); z.closeEntry()
            }
            put("[Content_Types].xml",
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""")
            put("_rels/.rels",
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
            put("xl/workbook.xml",
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="${esc(sheetName)}" sheetId="1" r:id="rId1"/></sheets></workbook>""")
            put("xl/_rels/workbook.xml.rels",
                """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""")
            put("xl/worksheets/sheet1.xml", sb.toString())
        }
    }

    private fun fit(text: String, p: Paint, maxW: Float): String {
        val n = p.breakText(text, true, maxW, null)
        return if (n < text.length) text.take(maxOf(0, n - 1)) + "…" else text
    }

    /** ملف PDF حقيقي A4 مع ترقيم صفحات تلقائي. النص العربي يُرسم بمحرك النص في أندرويد (تشكيل واتجاه صحيحان) */
    fun pdf(out: File, lines: List<PL>) {
        val doc = PdfDocument()
        val pw = 595; val ph = 842; val m = 36f
        val right = pw - m
        val usable = pw - 2 * m
        var pageNo = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(pw, ph, pageNo).create())
        var c = page.canvas
        var y = m
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.RIGHT }
        for (l in lines) {
            paint.textSize = l.size
            paint.isFakeBoldText = l.bold
            val lh = l.size * 1.75f
            if (y + lh > ph - m) {
                doc.finishPage(page)
                pageNo++
                page = doc.startPage(PdfDocument.PageInfo.Builder(pw, ph, pageNo).create())
                c = page.canvas
                y = m
            }
            y += lh
            val w = l.w
            if (w == null || l.cells.size == 1) {
                c.drawText(fit(l.cells.joinToString(" "), paint, usable), right, y, paint)
            } else {
                var x = right
                l.cells.forEachIndexed { i, t ->
                    val cw = usable * w[i]
                    c.drawText(fit(t, paint, cw - 6f), x, y, paint)
                    x -= cw
                }
            }
        }
        doc.finishPage(page)
        FileOutputStream(out).use { doc.writeTo(it) }
        doc.close()
    }

    fun share(ctx: Context, f: File, mime: String) {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
        val i = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "مشاركة").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
    }
}
