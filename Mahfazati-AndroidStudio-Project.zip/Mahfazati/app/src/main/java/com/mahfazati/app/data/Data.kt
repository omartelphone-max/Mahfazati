package com.mahfazati.app.data

import android.content.Context
import androidx.room.*
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "accounts")
data class Account(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val openingBalance: Long,
    val createdAt: Long
)

@Entity(tableName = "categories")
data class Category(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String
)

/** type: 0 مصروف، 1 دخل، 2 دين وارد (يزيد الرصيد)، 3 دين صادر (ينقص الرصيد) */
@Entity(
    tableName = "transactions",
    foreignKeys = [
        ForeignKey(entity = Account::class, parentColumns = ["id"], childColumns = ["accountId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = Category::class, parentColumns = ["id"], childColumns = ["categoryId"], onDelete = ForeignKey.SET_NULL),
        ForeignKey(entity = Debt::class, parentColumns = ["id"], childColumns = ["debtId"], onDelete = ForeignKey.SET_NULL)
    ],
    indices = [Index("accountId"), Index("categoryId"), Index("debtId"), Index("date"), Index(value = ["recurringKey"], unique = true)]
)
data class Tx(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: Int,
    val amount: Long,
    val date: Long,
    val accountId: Long,
    val categoryId: Long? = null,
    val source: String? = null,
    val note: String = "",
    val debtId: Long? = null,
    val recurringKey: String? = null
)

/** kind: 0 ديون لي عند الآخرين، 1 ديون عليّ للآخرين */
@Entity(
    tableName = "debts",
    foreignKeys = [ForeignKey(entity = Account::class, parentColumns = ["id"], childColumns = ["accountId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("accountId")]
)
data class Debt(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val personName: String,
    val kind: Int,
    val originalAmount: Long,
    val remaining: Long,
    val date: Long,
    val note: String,
    val accountId: Long
)

@Entity(
    tableName = "debt_payments",
    foreignKeys = [
        ForeignKey(entity = Debt::class, parentColumns = ["id"], childColumns = ["debtId"], onDelete = ForeignKey.CASCADE),
        ForeignKey(entity = Account::class, parentColumns = ["id"], childColumns = ["accountId"], onDelete = ForeignKey.RESTRICT)
    ],
    indices = [Index("debtId"), Index("accountId")]
)
data class DebtPayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val debtId: Long,
    val amount: Long,
    val date: Long,
    val accountId: Long,
    val note: String
)

/** ym = السنة*100 + الشهر ، وتسري الميزانية من هذا الشهر وما بعده */
@Entity(tableName = "budgets")
data class Budget(@PrimaryKey val ym: Int, val amount: Long)

/** frequency: 0 يومي، 1 أسبوعي، 2 شهري */
@Entity(
    tableName = "recurring",
    foreignKeys = [
        ForeignKey(entity = Account::class, parentColumns = ["id"], childColumns = ["accountId"], onDelete = ForeignKey.RESTRICT),
        ForeignKey(entity = Category::class, parentColumns = ["id"], childColumns = ["categoryId"], onDelete = ForeignKey.SET_NULL)
    ],
    indices = [Index("accountId"), Index("categoryId")]
)
data class Recurring(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amount: Long,
    val categoryId: Long?,
    val accountId: Long,
    val note: String,
    val frequency: Int,
    val nextDate: Long,
    val anchorDay: Int,
    val active: Boolean = true
)

@Entity(tableName = "settings")
data class SettingEntity(@PrimaryKey val skey: String, val sval: String)

@Dao
interface AppDao {
    @Query("SELECT * FROM accounts ORDER BY id") fun accounts(): Flow<List<Account>>
    @Query("SELECT * FROM categories ORDER BY id") fun categories(): Flow<List<Category>>
    @Query("SELECT * FROM transactions ORDER BY date DESC, id DESC") fun txs(): Flow<List<Tx>>
    @Query("SELECT * FROM debts ORDER BY date DESC, id DESC") fun debts(): Flow<List<Debt>>
    @Query("SELECT * FROM debt_payments ORDER BY date DESC, id DESC") fun payments(): Flow<List<DebtPayment>>
    @Query("SELECT * FROM budgets") fun budgets(): Flow<List<Budget>>
    @Query("SELECT * FROM recurring ORDER BY id") fun recurring(): Flow<List<Recurring>>
    @Query("SELECT * FROM settings") fun settings(): Flow<List<SettingEntity>>

    @Query("SELECT * FROM accounts ORDER BY id") suspend fun accountsOnce(): List<Account>
    @Query("SELECT * FROM categories ORDER BY id") suspend fun categoriesOnce(): List<Category>
    @Query("SELECT * FROM transactions ORDER BY id") suspend fun txsOnce(): List<Tx>
    @Query("SELECT * FROM debts ORDER BY id") suspend fun debtsOnce(): List<Debt>
    @Query("SELECT * FROM debt_payments ORDER BY id") suspend fun paymentsOnce(): List<DebtPayment>
    @Query("SELECT * FROM budgets") suspend fun budgetsOnce(): List<Budget>
    @Query("SELECT * FROM recurring ORDER BY id") suspend fun recurringOnce(): List<Recurring>

    @Query("SELECT * FROM accounts WHERE id=:id") suspend fun accountById(id: Long): Account?
    @Query("SELECT * FROM accounts WHERE name=:name LIMIT 1") suspend fun accountByName(name: String): Account?
    @Query("SELECT * FROM debts WHERE id=:id") suspend fun debtById(id: Long): Debt?
    @Query("SELECT * FROM budgets WHERE ym<=:ym ORDER BY ym DESC LIMIT 1") suspend fun budgetFor(ym: Int): Budget?
    @Query("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type=0 AND date BETWEEN :from AND :to")
    suspend fun sumExpense(from: Long, to: Long): Long
    @Query("SELECT sval FROM settings WHERE skey=:k") suspend fun setting(k: String): String?

    @Insert suspend fun insertAccount(a: Account): Long
    @Insert suspend fun insertCategory(c: Category): Long
    @Insert suspend fun insertTx(t: Tx): Long
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun insertTxIgnore(t: Tx): Long
    @Insert suspend fun insertDebt(d: Debt): Long
    @Insert suspend fun insertPayment(p: DebtPayment): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertBudget(b: Budget)
    @Insert suspend fun insertRecurring(r: Recurring): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putSetting(s: SettingEntity)

    @Update suspend fun updateAccount(a: Account)
    @Update suspend fun updateDebt(d: Debt)
    @Update suspend fun updateRecurring(r: Recurring)
    @Delete suspend fun deleteTx(t: Tx)
    @Delete suspend fun deleteRecurring(r: Recurring)

    @Query("DELETE FROM transactions") suspend fun clearTx()
    @Query("DELETE FROM debt_payments") suspend fun clearPayments()
    @Query("DELETE FROM debts") suspend fun clearDebts()
    @Query("DELETE FROM recurring") suspend fun clearRecurring()
    @Query("DELETE FROM budgets") suspend fun clearBudgets()
    @Query("DELETE FROM categories") suspend fun clearCategories()
    @Query("DELETE FROM accounts") suspend fun clearAccounts()
    @Query("DELETE FROM settings WHERE skey LIKE 'alert_%'") suspend fun clearAlerts()
}

@Database(
    entities = [Account::class, Category::class, Tx::class, Debt::class, DebtPayment::class,
        Budget::class, Recurring::class, SettingEntity::class],
    version = 1,
    exportSchema = false
)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): AppDao

    companion object {
        @Volatile private var inst: AppDb? = null

        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "mahfazati.db")
                .addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        db.execSQL(
                            "INSERT INTO categories(name) VALUES ('أكل وشرب'),('مواصلات'),('جوال وإنترنت'),('بيت وإيجار')," +
                                "('علاج'),('دين'),('تعليم'),('ترفيه'),('أخرى')"
                        )
                        db.execSQL(
                            "INSERT INTO accounts(name, openingBalance, createdAt) VALUES ('المحفظة', 0, strftime('%s','now')*1000)"
                        )
                    }
                })
                .build().also { inst = it }
        }
    }
}
