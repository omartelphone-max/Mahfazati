package com.mahfazati.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.mahfazati.app.data.BudgetAlert

object Notifier {
    private const val CH = "budget"

    fun init(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            ctx.getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel(CH, "تنبيهات الميزانية", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    fun text(a: BudgetAlert): String =
        if (a.level >= 100) "تجاوزت ميزانية الشهر: صرفت ${fmt(a.spent)} من ${fmt(a.budget)}"
        else "استهلكت 80% من ميزانية الشهر: ${fmt(a.spent)} من ${fmt(a.budget)}"

    fun budget(ctx: Context, a: BudgetAlert) {
        val pi = PendingIntent.getActivity(ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(if (a.level >= 100) "تنبيه: تجاوز الميزانية" else "تنبيه: اقتراب من الميزانية")
            .setContentText(text(a))
            .setStyle(NotificationCompat.BigTextStyle().bigText(text(a)))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try { NotificationManagerCompat.from(ctx).notify(if (a.level >= 100) 2 else 1, n) } catch (_: SecurityException) { }
    }
}
