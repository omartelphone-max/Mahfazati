@file:OptIn(ExperimentalMaterial3Api::class)

package com.mahfazati.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mahfazati.app.*
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.util.Locale

val Palette = listOf(
    Color(0xFF556B2F), Color(0xFFC9A94B), Color(0xFF8D6E63), Color(0xFF3F7F8C), Color(0xFFB5543A),
    Color(0xFF7E57C2), Color(0xFF6B8E23), Color(0xFFD08C60), Color(0xFF78909C)
)

@Composable
fun SubPage(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(title) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع") } },
            windowInsets = WindowInsets(0, 0, 0, 0)
        )
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
    }
}

@Composable
fun SubPageLazy(title: String, onBack: () -> Unit, content: LazyListScope.() -> Unit) {
    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(title) },
            navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع") } },
            windowInsets = WindowInsets(0, 0, 0, 0)
        )
        LazyColumn(
            Modifier.weight(1f), contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp), content = content
        )
    }
}

@Composable
fun <T> Dropdown(label: String, items: List<T>, selectedText: String, text: (T) -> String, onSelect: (T) -> Unit) {
    var exp by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = exp, onExpandedChange = { exp = it }, modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = selectedText, onValueChange = {}, readOnly = true, label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(exp) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )
        ExposedDropdownMenu(expanded = exp, onDismissRequest = { exp = false }) {
            items.forEach { DropdownMenuItem(text = { Text(text(it)) }, onClick = { onSelect(it); exp = false }) }
        }
    }
}

@Composable
fun DateField(label: String, date: LocalDate, onChange: (LocalDate) -> Unit) {
    var show by remember { mutableStateOf(false) }
    OutlinedButton(onClick = { show = true }, modifier = Modifier.fillMaxWidth().height(56.dp)) {
        Text("$label: ${dstr(date)}")
    }
    if (show) {
        val st = rememberDatePickerState(initialSelectedDateMillis = date.atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli())
        DatePickerDialog(
            onDismissRequest = { show = false },
            confirmButton = {
                TextButton(onClick = {
                    st.selectedDateMillis?.let { onChange(Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate()) }
                    show = false
                }) { Text("موافق") }
            },
            dismissButton = { TextButton(onClick = { show = false }) { Text("إلغاء") } }
        ) { DatePicker(state = st) }
    }
}

@Composable
fun AmountField(value: String, onChange: (String) -> Unit, label: String = "المبلغ (ريال يمني)") {
    OutlinedTextField(
        value = value, onValueChange = { onChange(it.filter { c -> c.isDigit() || c == ',' }) },
        label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        supportingText = { parseMoney(value)?.let { Text(fmt(it)) } }
    )
}

@Composable
fun FormDialog(title: String, okText: String = "حفظ", onDismiss: () -> Unit, onOk: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp), content = content) },
        confirmButton = { TextButton(onClick = onOk) { Text(okText) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier, container: Color = MaterialTheme.colorScheme.surface) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = container), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleMedium)
        }
    }
}

@Composable
fun BudgetBar(spent: Long, budget: Long) {
    val f = if (budget > 0) spent.toFloat() / budget else 0f
    val color = when { f >= 1f -> MaterialTheme.colorScheme.error; f >= 0.8f -> Gold; else -> MaterialTheme.colorScheme.primary }
    Column {
        LinearProgressIndicator(progress = { f.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(10.dp), color = color)
        Spacer(Modifier.height(4.dp))
        Text("المصروف ${fmt(spent)} من ${fmt(budget)} (${String.format(Locale.US, "%.0f", f * 100)}%)", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun BarChart(labels: List<String>, a: List<Long>, b: List<Long>? = null, colorA: Color, colorB: Color = Gold) {
    val onSurface = MaterialTheme.colorScheme.onSurface
    val density = LocalDensity.current
    Canvas(Modifier.fillMaxWidth().height(190.dp)) {
        val maxV = maxOf(1L, a.maxOrNull() ?: 0L, b?.maxOrNull() ?: 0L).toFloat()
        val padB = with(density) { 22.dp.toPx() }
        val padT = with(density) { 8.dp.toPx() }
        val h = size.height - padB - padT
        val n = labels.size
        val slot = size.width / n
        val paint = android.graphics.Paint().apply {
            color = onSurface.toArgb(); textSize = with(density) { 11.sp.toPx() }
            textAlign = android.graphics.Paint.Align.CENTER; isAntiAlias = true
        }
        for (i in 0 until n) {
            val cx = size.width - slot * (i + 0.5f) // من اليمين لليسار
            if (b == null) {
                val bh = h * a[i] / maxV
                drawRect(colorA, Offset(cx - slot * 0.3f, padT + h - bh), Size(slot * 0.6f, bh))
            } else {
                val ah = h * a[i] / maxV
                val bh = h * b[i] / maxV
                drawRect(colorA, Offset(cx - slot * 0.32f, padT + h - ah), Size(slot * 0.3f, ah))
                drawRect(colorB, Offset(cx + slot * 0.02f, padT + h - bh), Size(slot * 0.3f, bh))
            }
            drawContext.canvas.nativeCanvas.drawText(labels[i], cx, size.height - 4.dp.toPx(), paint)
        }
    }
}

@Composable
fun PieChart(slices: List<Pair<String, Long>>) {
    val total = slices.sumOf { it.second }.coerceAtLeast(1L)
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(170.dp)) {
                var start = -90f
                slices.forEachIndexed { i, s ->
                    val sweep = 360f * s.second / total
                    drawArc(Palette[i % Palette.size], start, sweep, true)
                    start += sweep
                }
            }
        }
        slices.forEachIndexed { i, s ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(14.dp).background(Palette[i % Palette.size], RoundedCornerShape(3.dp)))
                Spacer(Modifier.width(8.dp))
                Text(s.first, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                Text("${fmt(s.second)}  (${String.format(Locale.US, "%.1f", 100.0 * s.second / total)}%)", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
fun SectionTitle(t: String) = Text(t, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
