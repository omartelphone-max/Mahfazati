package com.mahfazati.app.data

import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.security.MessageDigest
import java.util.Locale

class AppError(message: String) : Exception(message)

data class BackupData(
    val accounts: List<Account>,
    val categories: List<Category>,
    val txs: List<Tx>,
    val debts: List<Debt>,
    val payments: List<DebtPayment>,
    val budgets: List<Budget>,
    val recurring: List<Recurring>,
    val createdAt: Long
)

object Backup {
    fun sha256(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8))
            .joinToString("") { String.format(Locale.US, "%02x", it) }

    private fun JSONObject.putN(k: String, v: Any?): JSONObject = put(k, v ?: JSONObject.NULL)
    private fun JSONObject.longN(k: String): Long? = if (isNull(k)) null else getLong(k)
    private fun JSONObject.strN(k: String): String? = if (isNull(k)) null else getString(k)
    private fun <T> arr(list: List<T>, f: (T) -> JSONObject): JSONArray {
        val a = JSONArray()
        list.forEach { a.put(f(it)) }
        return a
    }
    private fun <T> JSONObject.list(k: String, f: (JSONObject) -> T): List<T> {
        val a = getJSONArray(k)
        return List(a.length()) { f(a.getJSONObject(it)) }
    }

    fun export(d: BackupData): String {
        val p = JSONObject()
        p.put("accounts", arr(d.accounts) {
            JSONObject().put("id", it.id).put("name", it.name).put("openingBalance", it.openingBalance).put("createdAt", it.createdAt)
        })
        p.put("categories", arr(d.categories) { JSONObject().put("id", it.id).put("name", it.name) })
        p.put("transactions", arr(d.txs) {
            JSONObject().put("id", it.id).put("type", it.type).put("amount", it.amount).put("date", it.date)
                .put("accountId", it.accountId).putN("categoryId", it.categoryId).putN("source", it.source)
                .put("note", it.note).putN("debtId", it.debtId).putN("recurringKey", it.recurringKey)
        })
        p.put("debts", arr(d.debts) {
            JSONObject().put("id", it.id).put("personName", it.personName).put("kind", it.kind)
                .put("originalAmount", it.originalAmount).put("remaining", it.remaining).put("date", it.date)
                .put("note", it.note).put("accountId", it.accountId)
        })
        p.put("debtPayments", arr(d.payments) {
            JSONObject().put("id", it.id).put("debtId", it.debtId).put("amount", it.amount).put("date", it.date)
                .put("accountId", it.accountId).put("note", it.note)
        })
        p.put("budgets", arr(d.budgets) { JSONObject().put("ym", it.ym).put("amount", it.amount) })
        p.put("recurring", arr(d.recurring) {
            JSONObject().put("id", it.id).put("amount", it.amount).putN("categoryId", it.categoryId)
                .put("accountId", it.accountId).put("note", it.note).put("frequency", it.frequency)
                .put("nextDate", it.nextDate).put("anchorDay", it.anchorDay).put("active", it.active)
        })
        val payload = p.toString()
        return JSONObject()
            .put("app", "mahfazati")
            .put("version", 1)
            .put("createdAt", d.createdAt)
            .put("counts", JSONObject().put("accounts", d.accounts.size).put("transactions", d.txs.size).put("debts", d.debts.size))
            .put("checksum", sha256(payload))
            .put("payload", payload)
            .toString()
    }

    fun parse(text: String): BackupData {
        try {
            val root = JSONObject(text)
            if (root.optString("app") != "mahfazati") throw AppError("هذا الملف ليس نسخة احتياطية لتطبيق محفظتي")
            if (root.getInt("version") > 1) throw AppError("النسخة أحدث من إصدار التطبيق الحالي")
            val payload = root.getString("payload")
            if (sha256(payload) != root.getString("checksum"))
                throw AppError("الملف تالف أو تم تعديله (فشل فحص السلامة). لم يتم تغيير أي بيانات")
            val p = JSONObject(payload)
            val d = BackupData(
                accounts = p.list("accounts") { Account(it.getLong("id"), it.getString("name"), it.getLong("openingBalance"), it.getLong("createdAt")) },
                categories = p.list("categories") { Category(it.getLong("id"), it.getString("name")) },
                txs = p.list("transactions") {
                    Tx(it.getLong("id"), it.getInt("type"), it.getLong("amount"), it.getLong("date"), it.getLong("accountId"),
                        it.longN("categoryId"), it.strN("source"), it.getString("note"), it.longN("debtId"), it.strN("recurringKey"))
                },
                debts = p.list("debts") {
                    Debt(it.getLong("id"), it.getString("personName"), it.getInt("kind"), it.getLong("originalAmount"),
                        it.getLong("remaining"), it.getLong("date"), it.getString("note"), it.getLong("accountId"))
                },
                payments = p.list("debtPayments") {
                    DebtPayment(it.getLong("id"), it.getLong("debtId"), it.getLong("amount"), it.getLong("date"), it.getLong("accountId"), it.getString("note"))
                },
                budgets = p.list("budgets") { Budget(it.getInt("ym"), it.getLong("amount")) },
                recurring = p.list("recurring") {
                    Recurring(it.getLong("id"), it.getLong("amount"), it.longN("categoryId"), it.getLong("accountId"), it.getString("note"),
                        it.getInt("frequency"), it.getLong("nextDate"), it.getInt("anchorDay"), it.getBoolean("active"))
                },
                createdAt = root.optLong("createdAt")
            )
            validate(d)
            return d
        } catch (e: AppError) {
            throw e
        } catch (e: JSONException) {
            throw AppError("ملف النسخة الاحتياطية غير صالح أو ناقص")
        }
    }

    private fun validate(d: BackupData) {
        fun bad(m: String): Nothing = throw AppError("بيانات غير متسقة في الملف: $m")
        if (d.accounts.isEmpty()) bad("لا يوجد حسابات")
        if (d.categories.isEmpty()) bad("لا يوجد تصنيفات")
        val acc = d.accounts.map { it.id }
        if (acc.any { it <= 0 } || acc.toSet().size != acc.size || d.accounts.any { it.name.isBlank() }) bad("الحسابات")
        val cat = d.categories.map { it.id }
        if (cat.any { it <= 0 } || cat.toSet().size != cat.size) bad("التصنيفات")
        val accSet = acc.toSet(); val catSet = cat.toSet()
        val debtIds = d.debts.map { it.id }
        if (debtIds.any { it <= 0 } || debtIds.toSet().size != debtIds.size) bad("الديون")
        val debtSet = debtIds.toSet()
        for (x in d.debts) {
            if (x.kind !in 0..1 || x.originalAmount <= 0 || x.remaining !in 0..x.originalAmount || x.accountId !in accSet) bad("دين رقم ${x.id}")
        }
        val txIds = d.txs.map { it.id }
        if (txIds.any { it <= 0 } || txIds.toSet().size != txIds.size) bad("العمليات")
        val keys = d.txs.mapNotNull { it.recurringKey }
        if (keys.toSet().size != keys.size) bad("مفاتيح المصاريف المتكررة")
        for (t in d.txs) {
            val c = t.categoryId; val db = t.debtId
            if (t.type !in 0..3 || t.amount <= 0 || t.accountId !in accSet ||
                (c != null && c !in catSet) || (db != null && db !in debtSet)) bad("عملية رقم ${t.id}")
        }
        val payIds = d.payments.map { it.id }
        if (payIds.any { it <= 0 } || payIds.toSet().size != payIds.size) bad("الدفعات")
        for (p in d.payments) if (p.debtId !in debtSet || p.amount <= 0 || p.accountId !in accSet) bad("دفعة رقم ${p.id}")
        for (b in d.budgets) if (b.amount <= 0 || b.ym % 100 !in 1..12) bad("الميزانية")
        val recIds = d.recurring.map { it.id }
        if (recIds.any { it <= 0 } || recIds.toSet().size != recIds.size) bad("المتكررة")
        for (r in d.recurring) {
            val c = r.categoryId
            if (r.accountId !in accSet || (c != null && c !in catSet) || r.frequency !in 0..2 || r.amount <= 0 || r.anchorDay !in 1..31) bad("مصروف متكرر ${r.id}")
        }
    }
}
