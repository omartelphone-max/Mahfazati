package com.mahfazati.app.data

import androidx.room.withTransaction
import com.mahfazati.app.Ty
import com.mahfazati.app.fmt
import com.mahfazati.app.nextDate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.time.LocalDate

data class BudgetAlert(val level: Int, val spent: Long, val budget: Long)

class Repo(val db: AppDb) {
    val dao = db.dao()

    suspend fun addTx(t: Tx): Long = db.withTransaction {
        if (t.amount <= 0) throw AppError("المبلغ يجب أن يكون أكبر من صفر")
        if (dao.accountById(t.accountId) == null) throw AppError("اختر حساباً صحيحاً")
        dao.insertTx(t)
    }

    suspend fun deleteTx(t: Tx) {
        if (t.type != Ty.EXPENSE && t.type != Ty.INCOME) throw AppError("عمليات الديون تُدار من صفحة الديون")
        db.withTransaction { dao.deleteTx(t) }
    }

    suspend fun createAccount(name: String, opening: Long) = db.withTransaction {
        val n = name.trim()
        if (n.isEmpty()) throw AppError("أدخل اسم الحساب")
        if (dao.accountByName(n) != null) throw AppError("يوجد حساب بنفس الاسم")
        dao.insertAccount(Account(name = n, openingBalance = opening, createdAt = System.currentTimeMillis()))
    }

    suspend fun renameAccount(id: Long, name: String) = db.withTransaction {
        val n = name.trim()
        if (n.isEmpty()) throw AppError("أدخل اسم الحساب")
        val a = dao.accountById(id) ?: throw AppError("الحساب غير موجود")
        val other = dao.accountByName(n)
        if (other != null && other.id != id) throw AppError("يوجد حساب بنفس الاسم")
        dao.updateAccount(a.copy(name = n))
    }

    suspend fun addDebt(person: String, kind: Int, amount: Long, date: Long, note: String, accountId: Long, affectsBalance: Boolean) =
        db.withTransaction {
            if (person.isBlank()) throw AppError("أدخل اسم الشخص")
            if (amount <= 0) throw AppError("المبلغ يجب أن يكون أكبر من صفر")
            if (dao.accountById(accountId) == null) throw AppError("اختر حساباً صحيحاً")
            val id = dao.insertDebt(Debt(personName = person.trim(), kind = kind, originalAmount = amount, remaining = amount,
                date = date, note = note.trim(), accountId = accountId))
            if (affectsBalance) {
                // دين لي: خرج المال من حسابي. دين عليّ: دخل المال إلى حسابي. ولا يُحسب مصروفاً ولا دخلاً.
                dao.insertTx(Tx(type = if (kind == 0) Ty.DEBT_OUT else Ty.DEBT_IN, amount = amount, date = date,
                    accountId = accountId, note = (if (kind == 0) "إقراض: " else "اقتراض: ") + person.trim(), debtId = id))
            }
        }

    suspend fun payDebt(debtId: Long, amount: Long, date: Long, accountId: Long, note: String) = db.withTransaction {
        val d = dao.debtById(debtId) ?: throw AppError("الدين غير موجود")
        if (amount <= 0) throw AppError("المبلغ يجب أن يكون أكبر من صفر")
        if (amount > d.remaining) throw AppError("المبلغ أكبر من المتبقي (${fmt(d.remaining)})")
        if (dao.accountById(accountId) == null) throw AppError("اختر حساباً صحيحاً")
        dao.updateDebt(d.copy(remaining = d.remaining - amount))
        dao.insertPayment(DebtPayment(debtId = debtId, amount = amount, date = date, accountId = accountId, note = note.trim()))
        dao.insertTx(Tx(type = if (d.kind == 0) Ty.DEBT_IN else Ty.DEBT_OUT, amount = amount, date = date, accountId = accountId,
            note = (if (d.kind == 0) "استلام من " else "سداد إلى ") + d.personName, debtId = debtId))
    }

    suspend fun setBudget(ym: Int, amount: Long) = db.withTransaction {
        if (amount <= 0) throw AppError("أدخل ميزانية صحيحة")
        dao.insertBudget(Budget(ym, amount))
        dao.putSetting(SettingEntity("alert_$ym", "0"))
    }

    suspend fun addRecurring(r: Recurring) = db.withTransaction {
        if (r.amount <= 0) throw AppError("المبلغ يجب أن يكون أكبر من صفر")
        if (dao.accountById(r.accountId) == null) throw AppError("اختر حساباً صحيحاً")
        dao.insertRecurring(r)
    }

    /** يسجل المصاريف المتكررة المستحقة مرة واحدة فقط (مفتاح فريد لكل موعد) */
    suspend fun processRecurring(todayEpoch: Long): Int = db.withTransaction {
        var n = 0
        for (r in dao.recurringOnce().filter { it.active }) {
            var next = r.nextDate
            var guard = 0
            while (next <= todayEpoch && guard < 4000) {
                val ins = dao.insertTxIgnore(Tx(type = Ty.EXPENSE, amount = r.amount, date = next, accountId = r.accountId,
                    categoryId = r.categoryId, note = r.note.ifBlank { "مصروف متكرر" }, recurringKey = "${r.id}:$next"))
                if (ins > 0) n++
                next = nextDate(next, r.frequency, r.anchorDay)
                guard++
            }
            if (next != r.nextDate) dao.updateRecurring(r.copy(nextDate = next))
        }
        n
    }

    suspend fun checkBudget(ym: Int): BudgetAlert? {
        val b = dao.budgetFor(ym) ?: return null
        val from = LocalDate.of(ym / 100, ym % 100, 1)
        val to = from.withDayOfMonth(from.lengthOfMonth())
        val spent = dao.sumExpense(from.toEpochDay(), to.toEpochDay())
        val level = when {
            spent >= b.amount -> 100
            spent * 100 >= b.amount * 80 -> 80
            else -> 0
        }
        if (level == 0) return null
        val key = "alert_$ym"
        val done = dao.setting(key)?.toIntOrNull() ?: 0
        if (level <= done) return null
        dao.putSetting(SettingEntity(key, level.toString()))
        return BudgetAlert(level, spent, b.amount)
    }

    // ---------- الإعدادات و PIN ----------
    suspend fun getSetting(k: String): String? = dao.setting(k)
    suspend fun setSetting(k: String, v: String) = dao.putSetting(SettingEntity(k, v))
    suspend fun hasPin(): Boolean = dao.setting("pin_hash") != null

    suspend fun setPin(pin: String) {
        val salt = Sec.newSalt()
        val h = withContext(Dispatchers.Default) { Sec.hash(pin, salt) }
        db.withTransaction {
            dao.putSetting(SettingEntity("pin_salt", salt))
            dao.putSetting(SettingEntity("pin_hash", h))
        }
    }

    suspend fun verifyPin(pin: String): Boolean {
        val salt = dao.setting("pin_salt") ?: return false
        val stored = dao.setting("pin_hash") ?: return false
        val h = withContext(Dispatchers.Default) { Sec.hash(pin, salt) }
        return Sec.same(h, stored)
    }

    // ---------- النسخ الاحتياطي ----------
    suspend fun snapshot(): BackupData = db.withTransaction {
        BackupData(dao.accountsOnce(), dao.categoriesOnce(), dao.txsOnce(), dao.debtsOnce(), dao.paymentsOnce(),
            dao.budgetsOnce(), dao.recurringOnce(), System.currentTimeMillis())
    }

    suspend fun restore(d: BackupData, replace: Boolean) = db.withTransaction {
        if (replace) {
            dao.clearTx(); dao.clearPayments(); dao.clearDebts(); dao.clearRecurring()
            dao.clearBudgets(); dao.clearCategories(); dao.clearAccounts()
            d.accounts.forEach { dao.insertAccount(it) }
            d.categories.forEach { dao.insertCategory(it) }
            d.debts.forEach { dao.insertDebt(it) }
            d.txs.forEach { dao.insertTx(it) }
            d.payments.forEach { dao.insertPayment(it) }
            d.budgets.forEach { dao.insertBudget(it) }
            d.recurring.forEach { dao.insertRecurring(it) }
        } else {
            merge(d)
        }
        dao.clearAlerts()
    }

    private suspend fun merge(d: BackupData) {
        val accMap = HashMap<Long, Long>()
        val exAcc = dao.accountsOnce().associateBy { it.name }
        for (a in d.accounts) accMap[a.id] = exAcc[a.name]?.id ?: dao.insertAccount(a.copy(id = 0))

        val catMap = HashMap<Long, Long>()
        val exCat = dao.categoriesOnce().associateBy { it.name }
        for (c in d.categories) catMap[c.id] = exCat[c.name]?.id ?: dao.insertCategory(c.copy(id = 0))

        val debtMap = HashMap<Long, Long>()
        val used = HashSet<Long>()
        val exDebts = dao.debtsOnce()
        for (x in d.debts) {
            val m = exDebts.firstOrNull {
                it.id !in used && it.personName == x.personName && it.kind == x.kind &&
                    it.originalAmount == x.originalAmount && it.date == x.date
            }
            if (m != null) { used.add(m.id); debtMap[x.id] = m.id }
            else debtMap[x.id] = dao.insertDebt(x.copy(id = 0, accountId = accMap.getValue(x.accountId)))
        }

        fun sig(t: Tx) = listOf(t.type, t.amount, t.date, t.accountId, t.categoryId, t.source, t.note, t.debtId)
        val cnt = HashMap<List<Any?>, Int>()
        dao.txsOnce().forEach { cnt.merge(sig(it), 1, Int::plus) }
        for (t in d.txs) {
            val m = t.copy(id = 0, accountId = accMap.getValue(t.accountId), categoryId = t.categoryId?.let { catMap[it] },
                debtId = t.debtId?.let { debtMap[it] }, recurringKey = null)
            val s = sig(m)
            val c = cnt[s] ?: 0
            if (c > 0) cnt[s] = c - 1 else dao.insertTx(m)
        }

        fun psig(p: DebtPayment) = listOf(p.debtId, p.amount, p.date, p.accountId, p.note)
        val pc = HashMap<List<Any?>, Int>()
        dao.paymentsOnce().forEach { pc.merge(psig(it), 1, Int::plus) }
        for (p in d.payments) {
            val m = p.copy(id = 0, debtId = debtMap.getValue(p.debtId), accountId = accMap.getValue(p.accountId))
            val s = psig(m)
            val c = pc[s] ?: 0
            if (c > 0) pc[s] = c - 1 else dao.insertPayment(m)
        }
        // المتبقي = الأصلي - مجموع الدفعات (يضمن اتساق الديون بعد الدمج)
        val allPay = dao.paymentsOnce().groupBy { it.debtId }
        for (x in dao.debtsOnce()) {
            val rem = (x.originalAmount - (allPay[x.id]?.sumOf { it.amount } ?: 0L)).coerceIn(0, x.originalAmount)
            if (rem != x.remaining) dao.updateDebt(x.copy(remaining = rem))
        }

        val exBud = dao.budgetsOnce().map { it.ym }.toSet()
        d.budgets.filter { it.ym !in exBud }.forEach { dao.insertBudget(it) }

        val exRec = dao.recurringOnce().map { listOf(it.amount, it.accountId, it.frequency, it.note) }.toMutableList()
        for (r in d.recurring) {
            val m = r.copy(id = 0, accountId = accMap.getValue(r.accountId), categoryId = r.categoryId?.let { catMap[it] })
            val s = listOf(m.amount, m.accountId, m.frequency, m.note)
            if (s !in exRec) { dao.insertRecurring(m); exRec.add(s) }
        }
    }
}
