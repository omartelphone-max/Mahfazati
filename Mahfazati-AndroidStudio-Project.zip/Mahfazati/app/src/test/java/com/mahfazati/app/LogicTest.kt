package com.mahfazati.app

import com.mahfazati.app.data.*
import org.junit.Assert.*
import org.junit.Test
import java.time.LocalDate

class LogicTest {
    @Test fun parseMoneyWorks() {
        assertEquals(100000L, parseMoney("100,000"))
        assertEquals(5L, parseMoney("٥"))
        assertNull(parseMoney("1.5"))
        assertNull(parseMoney("0"))
        assertNull(parseMoney(""))
    }

    @Test fun balanceScenario() {
        val a = Account(1, "x", 0, 0)
        val tx = listOf(
            Tx(type = Ty.INCOME, amount = 100000, date = 0, accountId = 1),
            Tx(type = Ty.EXPENSE, amount = 10000, date = 0, accountId = 1)
        )
        assertEquals(90000L, balanceOf(a, tx))
    }

    @Test fun debtMovementsAffectBalanceCorrectly() {
        val a = Account(1, "x", 50000, 0)
        val tx = listOf(
            Tx(type = Ty.DEBT_OUT, amount = 20000, date = 0, accountId = 1),
            Tx(type = Ty.DEBT_IN, amount = 5000, date = 0, accountId = 1)
        )
        assertEquals(35000L, balanceOf(a, tx))
    }

    @Test fun monthlyRecurrenceKeepsAnchor() {
        val jan31 = LocalDate.of(2026, 1, 31).toEpochDay()
        val feb = nextDate(jan31, 2, 31)
        assertEquals(LocalDate.of(2026, 2, 28).toEpochDay(), feb)
        assertEquals(LocalDate.of(2026, 3, 31).toEpochDay(), nextDate(feb, 2, 31))
    }

    private fun sample() = BackupData(
        listOf(Account(1, "المحفظة", 1000, 1)), listOf(Category(1, "أكل وشرب")),
        listOf(Tx(1, Ty.EXPENSE, 500, 100, 1, 1, null, "غداء", null, null)),
        emptyList(), emptyList(), listOf(Budget(202611, 100000)), emptyList(), 1
    )

    @Test fun backupRoundTrip() {
        val back = Backup.parse(Backup.export(sample()))
        assertEquals(sample().txs, back.txs)
        assertEquals(sample().accounts, back.accounts)
        assertEquals(sample().budgets, back.budgets)
    }

    @Test fun tamperedBackupRejected() {
        val json = Backup.export(sample()).replace("غداء", "عشاء")
        assertThrows(AppError::class.java) { Backup.parse(json) }
    }

    @Test fun garbageRejected() {
        assertThrows(AppError::class.java) { Backup.parse("not json") }
    }
}
